NOCTURNE WORKBENCH 0.9.0-rc.2
Extract ALL files. Open Nocturne-Workbench.html or Nocturne-Workbench-Docs.html.
Both pages are self-contained; keep their names together for companion links.
The complete SDK is a separate ZIP. No automatic capture or provider connection.
Local tests passed; Rust/platform/GPU qualification is explicitly separate.
